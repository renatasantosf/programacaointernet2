export class Parceiro {
    nomePagina:string;
    urlPagina:string;
    nomeWebMaster:string;
    email:string;
    codigo:number;
    
}
