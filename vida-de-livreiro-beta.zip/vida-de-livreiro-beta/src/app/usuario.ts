export class Usuario {
    codigo:number;
    nome:string;
    senha:string;
    email: string;
    sobre:string;
    senhaAux1:string;
    senhaAux2:string;
   
}
