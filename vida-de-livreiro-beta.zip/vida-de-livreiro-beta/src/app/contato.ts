export class Contato {
    nome:string;
    sobrenome:string;
    email:string;
    telefone:string;
    mensagem:string;
    codigo:number;
    
}
