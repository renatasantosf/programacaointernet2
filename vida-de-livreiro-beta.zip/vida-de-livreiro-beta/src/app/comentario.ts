export class Comentario {
    codigo:number;
    nome:string;
    texto:string;
        
}
