import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paginainicial',
  templateUrl: './paginainicial.component.html',
  styleUrls: ['./paginainicial.component.css']
})
export class PaginainicialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  
  }

}
