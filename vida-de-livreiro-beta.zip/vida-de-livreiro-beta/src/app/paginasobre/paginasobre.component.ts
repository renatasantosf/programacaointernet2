import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paginasobre',
  templateUrl: './paginasobre.component.html',
  styleUrls: ['./paginasobre.component.css']
})
export class PaginasobreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
