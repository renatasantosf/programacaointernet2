export class Pedido {
    codigo:number;
    nomeobra:string;
    autor:string;
    tipolit:string;
    descricao:string;
    cod_usuario:number;
    
}
