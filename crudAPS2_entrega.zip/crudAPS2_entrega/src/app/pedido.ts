export class Pedido {
    codigo: number;
    nomeLivro: string;
    descricao: string;

    
}
